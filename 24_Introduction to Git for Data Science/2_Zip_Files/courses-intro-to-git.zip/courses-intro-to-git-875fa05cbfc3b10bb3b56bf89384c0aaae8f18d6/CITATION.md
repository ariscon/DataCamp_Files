---
---
# Citation

Please cite this lesson as:

```
Greg Wilson: "Introduction to Git for Data Science".  DataCamp, 2017, https://www.datacamp.com/courses/intro-to-git.
```
